
#******************  PYTHON DAY1 ASSIGNMENT  ***************

#**********  GANESH KUMAR.E  *******  EMP ID: 155425  ******

#__________________ Program 1__________________

name=input("Enter Your Name: ")
print ("Hello",name)

#__________________ Program 2__________________

n1=int(input("Enter number 1: "))
n2=int(input("Enter number 2: "))
n3=n1+n2
if n3>=0:
    print("Positive")
else:
    print("Negative")

#__________________ Program 3__________________

n1=int(input("Enter the number to be stored: "))
n2=int(input("Enter the number to be checked: "))
while (True):
    if n2!=n1:
        n2=int(input("Enter the correct number: "))
    else:
        print("Correct")
        break
#____________________Program 4_________________
    
Firstname=input("Enter the First name: ")
Lastname=input("Enter the Last name: ")
print("Wholename is {0}.{1}".format(Firstname,Lastname))

#____________________Program 5_________________

print("Enter the text to Toggle Case:")
n1=input()
print(n1.swapcase())

#___________________ Program 6_____________________

l1=list(input("Enter the list: "))
sum1=0
multiply=1
s2=[int (i) for i in l1]
for j in s2:
    sum1+=j
    multiply*=j

print(sum1)
print(multiply)

#____________________Program 7__________________

n1=input("Enter anything: ")
l1=list(input("Enter the list: "))
flag=0
for i in l1:
    if n1==i:
        flag=1
        print("Match")
        break
    else:
        continue
       
if flag ==0:
    print("Not")

#____________________Program 8__________________

l1=list(input("Enter the list1: "))
l2=list(input("Enter the list2: "))
flag=0
for i in l1:
    for j in l2:
        if i==j:
            flag=1
            break
    else:
        continue
       
if flag ==0:
    print("False")
else:
    print("True")
       
#__________________ Program 9__________________

l=list(input("Enter the list: "))
for j in [int (i) for i in l]:
    print(j*'*')
#With Range Function
    
#for j in range(0,len(l)):
   # print('*'*int(l[j]))
    
