name=input("Enter Your Name: ")
print ("Hello",name)
