#______________Program 3_________________________
n1=int(input("Enter the number to be stored: "))
n2=int(input("Enter the number to be checked: "))
while (True):
    if n2!=n1:
        n2=int(input("Enter the correct number: "))
    else:
        print("Correct")
        break
      


