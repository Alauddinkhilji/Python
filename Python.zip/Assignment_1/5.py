#___________________Program 5_________________________
n1=input()
print(n1.swapcase())
