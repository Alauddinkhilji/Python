#____________________Program 4___________________
Firstname=input("Enter the First name: ")
Lastname=input("Enter the Last name: ")
print("Wholename is {0}.{1}".format(Firstname,Lastname))
