n1=int(input("Enter number 1: "))
n2=int(input("Enter number 2: "))
n3=n1+n2
if n3>=0:
    print("Positive")
else:
    print("Negative")
