#____________________Program 7__________________
n1=input("Enter anything: ")
l1=list(input("Enter the list: "))
flag=0
for i in l1:
    if n1==i:
        flag=1
        print("Match")
        break
    else:
        continue
       
if flag ==0:
    print("Not")
       
        
    
