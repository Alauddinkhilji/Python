#___________________ Program 6_____________________
l1=list(input("Enter the list: "))
sum1=0
multiply=1
s2=[int (i) for i in l1]
for j in s2:
    sum1+=j
    multiply*=j

print(sum1)
print(multiply)
