#____________________Program 8__________________
l1=list(input("Enter the list1: "))
l2=list(input("Enter the list2: "))
flag=0
for i in l1:
    for j in l2:
        if i==j:
            flag=1
            break
    else:
        continue
       
if flag ==0:
    print("False")
else:
    print("True")
       
