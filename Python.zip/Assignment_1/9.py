#__________________ Program 9__________________

l=list(input("Enter the list: "))

#---------------------------------------------------
for j in [int (i) for i in l]:
    print(j*'*')
#---------------------------------------------------
#With Range Function
    
#for j in range(0,len(l)):
   # print('*'*int(l[j]))
    
