#_________________Program 4___________________

def find_longest_word(n):
    t=n.split();
    word=""
    lenm=0
    for j in t:
        if lenm<len(j):
            lenm=len(j)
            word=j
    return word
            
n=input("Enter list of words: ")
word = find_longest_word(n)
print(word)
