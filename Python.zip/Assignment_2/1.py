#_____________Program 1__________________
def generate_n_chars(n,c):
    for j in range(0,n):
        s=n*c
        return s

n=int(input("Enter number: "))
c=input("Enter character: ")
s=generate_n_chars(n,c)
print(s)
