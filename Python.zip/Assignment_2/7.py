#___________________ Program 7 ___________________________
from string import ascii_lowercase
def check(s):
    return set(ascii_lowercase)-set(s.lower())==set([])
text=input("Enter String: ")
if(check(text)==True):
    print("Yes! It is a pangram")
else:
    print("No! It is not a pangram")
