#________________________ Program 6 ___________________________________________
import string
a=string.punctuation
b=input("Enter the phrase: ")
word=''.join([x for x in b.lower() if not x in a]).replace(' ','') # convert to lower, remove all spaces
r=word[::-1] # to reverse a string
print("{0} in reverse is {1}".format(word,r))
if r==word:
    print("So It is a palindrome")
else:
    print("Its not a palindrome")
