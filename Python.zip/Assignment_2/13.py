#________________________ Program 13____________________________
f=open("Emps.txt",'r')
d=f.read()
f.close()
x=d.split(',')
id=x[0]
name=x[1]
salary=x[2]
g=open("Empnew.txt", 'w')
g.write(str(id) +','+ name + ',' + str(salary))
print("New file created with existing file data")
print("ID:{0}, Name: {1}, Salary: {2}".format(id,name,salary))
g.close()
