def max_in_list(n):
    l=n[0]
    for j in n:
            if(l<j):
                l=j
    return l
            
n=list(input("Enter number: "))
l=max_in_list(n)
print(l)
