class date:
    import datetime
    DT=datetime.datetime.now()
    def __init__(self):
        self.y=date.DT.year
        pass
    def displayTime(self):
        print("time-{0}:{1}:{2}".format(date.DT.hour,date.DT.minute,date.DT.second))
    def displayDate(self):
        print("date-{0}/{1}/{2}".format(date.DT.day,date.DT.month,date.DT.year))

class usedate:
    def __init__(self):
        d=date()
        d.displayTime()
        d.displayDate()
usedate()
