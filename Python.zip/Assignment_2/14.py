import math
print (dir(math))
import numpy
print (dir(numpy))
