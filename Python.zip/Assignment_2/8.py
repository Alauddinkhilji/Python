dict={"merry":"god","christmas":"jul","and":"och","happy":"gott","new":"nytt","year":"ar"}

def translate(e):
    s=[]
    for i in e:
        s.append(dict.get(i))
    print(s)
x=(input("Enter list:")).split(" ")
translate(x)

