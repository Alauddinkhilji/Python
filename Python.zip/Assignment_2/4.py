#____________________Program 3_______________________

a=input("Enter the list of words: ").split(',')
b=[]
for j in a:
    b.append(len(j))

print (b)
