import Calc

a = list(input("Enter array1: "))
b = list(input("Enter array2: "))
c=list(Calc.add(a,b))
d=list(Calc.sub(a,b))
print("Addition is: ",c)
print("Subtraction is: ",d)
sr=list(Calc.sort1(c))
print("Sorting is: ",sr)
print("Maximum is: ",Calc.max1(c))
