def add(a,b):
    s=([(int(i) + int(j)) for i, j in zip(a, b)])
    return s

def sub(a,b):
    s=([(int(i) - int(j)) for i, j in zip(a, b)])
    return s

def sort1(c):
    c.sort()
    return c

def max1(c):
    m=max(c)
    return m
    


